<?php
session_start();
?>
<html><head><title>Sign Up</title></head>
<body bgcolor="lightblue"><font size="+1" >
<?php

if (isset($_POST["submit"])) {
$dbservername = "localhost";
$dbusername = "u403979365_root";
$dbpassword = "35248910";
$dbname = "u403979365_user";
$usernameval = $passwordval = 0;

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if (!$conn) {
    die("Connection failed : " . mysqli_connect_error() . "<br>");
} else {

   if (empty($_POST["username"])) {
     echo "Username cannot be empty<br>";
   } else {
     $username = test_input($_POST["username"]);
	 $usernameval = 1;
	 if (!preg_match("/^[a-zA-Z0-9]*$/",$username)) {
       $usernameval = 0;
	   echo "Only letters and numbers allowed for username<br>"; 
     }
   }

   if (empty($_POST["password"])) {
     echo "Password cannot be empty<br>";
   } else {
     $password = test_input($_POST["password"]);
	 $passwordval = 1;
	 if (!preg_match("/^[a-zA-Z0-9]*$/",$password)) {
       $passwordval = 0;
	   echo "Only letters and numbers allowed for password<br>"; 
     }
   }
}

$_SESSION["login"] = "true";
$_SESSION["username"] = $username;
$_SESSION["password"] = $password;

$sql = mysqli_query($conn,"SELECT * FROM user WHERE username='".$username."' AND password='".$password."'");
$result = mysqli_fetch_assoc($sql);
if (count($result)>=1) {
	$_SESSION["id"]= $result["id"];
	$_SESSION["firstname"] = $result["firstname"];
	$_SESSION["lastname"] = $result["lastname"];
	
	echo "Login is succeedd.<br>" ;
	echo "You will redirect to your profile in 1 seconds.<br>";
	header("refresh:1; url=userpage.php");
} else {
	echo "Invalid username or password.<br>";
	echo "Please try to login again!<br>";
	echo "You will redirect to login page in 3 seconds.";
	header("refresh:3; url=login2.php");
}



mysqli_close($conn);

} else {
?>
<center>
<h1><img src="loginbutton.png" alt="Login" /></h1>
<table>
<tr>
<form method="POST" action="<?php  echo $_SERVER['PHP_SELF'] ?>">
<td>Username</td><td>
<input type="text" name="username"></td>
</tr>
<tr>
<td>Password</td><td>
<input type="password" name="password"></td>
</tr>
<tr>
<td><input type="submit" name="submit" value="Login"></td>
</tr>
</form>
</table>
</center>
<?php
}
?>
</body>
</html>

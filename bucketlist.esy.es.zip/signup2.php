<html><head><title>Sign Up</title></head>
<body bgcolor="lightblue"><font size="+1" >
<?php
if (isset($_POST["submit"])) {
$dbservername = "localhost";
$dbusername = "u403979365_root";
$dbpassword = "35248910";
$dbname = "u403979365_user";
$firstnameval = $lastnameval = $emailval = $usernameval = $passwordval = 0;

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if (!$conn) {
    die("Connection to mysql failed : " . mysqli_connect_error() . "<br>");
} else {

   if (empty($_POST["firstname"])) {
     echo "First name cannot be empty.<br>";
   } else {
     $firstname = test_input($_POST["firstname"]);
	 $firstnameval = 1;
     if (!preg_match("/^[a-zA-Z ]*$/",$firstname)) {
	   $firstnameval = 0;
       echo "Only letters and white space allowed for first name.<br>";
     }
   }
   
   if (empty($_POST["lastname"])) {
     echo "Last name cannot be empty.<br>";
   } else {
     $lastname = test_input($_POST["lastname"]);
	 $lastnameval = 1;
     if (!preg_match("/^[a-zA-Z ]*$/",$lastname)) {
	   $lastnameval = 0;
       echo "Only letters and white space allowed for last name.<br>"; 
     }
   }
   
   if (empty($_POST["email"])) {
     echo "Email cannot be empty.<br>";
   } else {
     $email = test_input($_POST["email"]);
	 $emailval = 1;
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailval = 0;
	   echo "Invalid email format(valid form -> example@domain.com).<br>"; 
     }
   }

   if (empty($_POST["username"])) {
     echo "Username cannot be empty.<br>";
   } else {
     $username = test_input($_POST["username"]);
	 $usernameval = 1;
	 if (!preg_match("/^[a-zA-Z0-9]*$/",$username)) {
       $usernameval = 0;
	   echo "Only letters and numbers allowed for username.<br>"; 
     }
   }

   if (empty($_POST["password"])) {
     echo "Password cannot be empty.<br>";
   } else {
     $password = test_input($_POST["password"]);
	 $passwordval = 1;
	 if (!preg_match("/^[a-zA-Z0-9]*$/",$password)) {
       $passwordval = 0;
	   echo "Only letters and numbers allowed for password.<br>"; 
     }
   }
}

if (($firstnameval == 1) && ($lastnameval == 1) && ($emailval == 1) && ($usernameval == 1) && ($passwordval == 1)) {
	$sql = "INSERT INTO user (firstname, lastname, email, username, password)
	VALUES ('$firstname', '$lastname', '$email', '$username', '$password')";
	
	if (mysqli_query($conn, $sql)) {
		echo "Your registration is completed.<br>";
		echo "You will redirect login page in 1 seconds.";
		header("refresh:1; url=login2.php");
		exit;
	} else {
		echo "Data insertion failed : " . mysqli_error($conn) . "<br>";
		echo "You will redirect Sign Up page again in 3 seconds.";
		header("refresh:3; url=signup2.php");
		exit;
	}
} else {
	echo "Please fill sign up form again!<br>" ;
	echo "You will redirect Sign Up page again in 3 seconds.";
	header("refresh:3; url=signup2.php");
	exit;
}

mysqli_close($conn);

} else {
?>

<center>
<h1><img src="signupbutton.png" alt="SignUp" /></h1>
<table>
<tr>
<form method="POST" action="<?php  echo $_SERVER['PHP_SELF'] ?>">
<td>First Name</td>
<td><input type="text" name="firstname"></td>
</tr>
<tr>
<td>Last Name</td>
<td><input type="text" name="lastname"></td>
</tr>
<tr>
<td>Email</td>
<td><input type="text" name="email"></td>
</tr>
<tr>
<td>Username</td><td>
<input type="text" name="username"></td>
</tr>
<tr>
<td>Password</td><td>
<input type="password" name="password"></td>
</tr>
<tr>
<td><input type="submit" name="submit" value="Sign Up"></td>
</tr>
</form>
</table>
</center>

<?php
}
?>
</body>
</html>

<?php
session_start();
?>
<html><head><title>User Page</title></head>
<body bgcolor="lightblue">
<?php

$dbservername = "localhost";
$dbusername = "u403979365_root";
$dbpassword = "35248910";
$dbname = "u403979365_user";

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if (!$conn) {
    die("Connection failed : " . mysqli_connect_error() . "<br>");
} 

$username = $_SESSION["username"];

$sql = mysqli_query($conn,"SELECT * FROM user WHERE username='".$username."'");
$result = mysqli_fetch_assoc($sql);
if (count($result)>=1) {
	$_SESSION["id"]=$result["id"];
	
	
	echo "<h2><b><center>USER PROFILE INFORMATIONS</center></b></h2>";
	echo "<center>Registration ID: " . $result["id"] . "<br>Name: " . $result["firstname"] . " " . $result["lastname"] . "<br>Email: " . $result["email"] . "<br>Username: ". $result["username"] . "<br>Password: " .  $result["password"] . "</center>";
} else {
	echo "Error to display profile informations." . $mysqli_error($conn) . "<br>";
}

	
mysqli_close($conn);
?>
<hr>
<center><h2><b>BUCKET LIST</b></h2>
<form method="POST" action="bucketlist.php">
<input type="checkbox" name="thing1" value="Grand Canyon" />(1) GET LOST FOR WORDS AT THE GRAND CANYON<br>
<input type="checkbox" name="thing2" value="Jordan" />(2) WALK THE SIQ TO PETRA, JORDAN<br>
<input type="checkbox" name="thing3" value="Liverpool" />(3) THROW YOURSELF INTO LIVERPOOL'S NIGHTLIFE, ENGLAND<br>
<input type="checkbox" name="thing4" value="Australia" />(4) SAIL THE WHITSUNDAYS, AUSTRALIA<br>
<input type="checkbox" name="thing5" value="India" />(5) VISIT THE TAJ BY MOONLIGHT, INDIA<br>
<input type="checkbox" name="thing6" value="Japan" />(6) SEE THE FLORAL WAVE OF CHERRY BLOSSOMS, JAPAN<br>
<input type="checkbox" name="thing7" value="Bolivia" />(7) TRAVERSE THE SALAR DE UYUNI, BOLIVIA<br>
<input type="checkbox" name="thing8" value="Ecuador" />(8) EXPLORE THE GALAIPAGOS ISLANDS, ECUADOR<br>
<input type="checkbox" name="thing9" value="Scotland" />(9) TOAST BAD WEATHER IN THE SCOTTISH HIGHLANDS<br>
<input type="checkbox" name="thing10" value="Canada" />(10) BED DOWN IN AN IGLOO, CANADA<br>
<input type="submit" name="submit" value="Done"> 
</form>
</center>

<hr><center>
<a href='updateprofile.php'>Click here to Edit Profile<br></a>
<a href='uploadphoto.html'>Click here to Upload a Photo<br></a>
<a href='fileupload.html'>Click here to Upload a File<br></a><br><br>
<a href='logout.php'>Logout<br></a>
</center>
</body>
</html>

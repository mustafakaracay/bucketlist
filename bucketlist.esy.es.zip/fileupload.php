<html><head><title>File Upload</title></head>
<body bgcolor="lightblue"><font size="+1" >
<?php
 echo "<b>File uploaded successfully.</b><br><br>";
 $handle=fopen($_FILES['user_file']['tmp_name'], "r");
 while(!feof($handle)){
    $text=fgets($handle);
    echo $text,"<br />";
 }
?>
<br><a href="userpage.php"> Click Here to Go Back Your Profile </a>
</body>
</html>
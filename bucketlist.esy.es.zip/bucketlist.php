<html><head><title>Bucket List</title></head>
<body bgcolor="lightblue"><font size="+1" >
<?php
 extract($_REQUEST);
 if ( $thing1 ){
     echo "<b>GET LOST FOR WORDS AT THE GRAND CANYON</b><br>";
     echo "After pondering the Grand Canyon for the first time most visitors are stunned into silence. The problem is not lack of words. It is just that the canyon is so vast and so deep, that the vista stretches so far across your line of vision. The facts are similarly mind-boggling: it is around 277 miles long and one mile deep. Think of it like a mountain range upside down. The abruptness of the drop is bizarre and, for some, unnerving. But the Grand Canyon is like that: it picks you up and takes you out of your comfort zone, dropping you back just that little bit changed.<br>";
	 echo "<a href='userpage.php'>Click here to Your Profile<br></a>";
 } else if ($thing2) {
	 echo "<b>WALK THE SIQ TO PETRA, JORDAN</b><br>";
	 echo "The fabled site of Petra is simply awe-inspiring. This rock-carved Nabataean city has entranced travellers for centuries with its ornate facades and classical architecture. Perhaps the most magical views lies at the end of the Siq, a dramatic natural gorge that�s still the main entrance. Here, you emerge from the bizarrely eroded cliffs onto an extraordinary view: the famous facade of Petra�s Treasury looming before you<br>";
	 echo "<a href='userpage.php'>Click here to Your Profile<br></a>";
 } else if ($thing3) {
	 echo "<b>THROW YOURSELF INTO LIVERPOOL'S NIGHTLIFE, ENGLAND</b><br>";
	 echo "Forget any preconceptions you may have about bar crawling in Liverpool. The reality is as far from fake tans, big hair and silly scally stereotypes as you can get � this scene is creative, convivial and bursting with joie de vivre. Countless great drinking holes pepper the city, and you could happily spend a lifetime sampling them all. Make for Seel Street, in the Ropewalks quarter, and the �ber-arty Baltic Triangle, the apogee of this organic after-dark and the blossoming home of Liverpool�s creative and digital media scene. Intimate, bare-brick gin and whiskey joints, craft beer and killer cocktails await.<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 } else if ($thing4) {
	 echo "<b>SAIL THE WHITSUNDAYS, AUSTRALIA</b><br>";
	 echo "There�s a distinct feeling of d�j� vu cruising in a sailboat among the Whitsunday Islands. Presently it comes to you: you�ve been here many times, in your lottery fantasies. This tropical idyll of turquoise seas lapping ivory sands against a backdrop of dense green foliage is ingrained in our imagination. Life on board here becomes sybaritically simple. A shower is as easy as diving into the surrounding water, and your bed is the deck of the boat or the sand on the beach.<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 } else if ($thing5) {
	 echo "<b>VISIT THE TAJ BY MOONLIGHT, INDIA</b><br>";
	 echo "There�s no such thing as an unflattering angle of the Taj Mahal, the world�s most beautiful building, commissioned by Mughal Emperor Shah Jahan as a memorial to his beloved wife. But the love and sadness embodied by the Taj are never more palpable than during the full moon, when the complex is opened at night. At this time, visitors are hushed into silence by the building�s ethereal form, rising melancholically from the riverbank yet seemingly shimmering with life.<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 } else if ($thing6) {
	 echo "<b>SEE THE FLORAL WAVE OF CHERRY BLOSSOMS, JAPAN</b><br>";
     echo "In Japan, spring sees the country gradually coated in a light pink shade, soft petals slowly clustering on their branches as if puffed through by some benevolent underground spirit. The sakura- zensen, or cherry blossom front, flushes like a floral wave that laps the country from south to north and is followed ardently by the Japanese. Among the best places to see it are Kiyomizu-tera in Kyoto, Tokyo�s Ueno Park or the castles in Osaka or Himeji, all of which are lent a dreamlike air by the arrival of the blossom each spring.<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 } else if ($thing7) {
	 echo "<b>TRAVERSE THE SALAR DE UYUNI, BOLIVIA</b><br>";
     echo "The immaculate white expanse of the Salar de Uyuni is one of Bolivia�s most extraordinary attractions. This is the largest salt lake in the world, capped by a thick, hard crust of salt, easily capable of supporting the weight of a car. It�s perhaps best seen after a heavy rainfall, when the Salar transforms into an immense mirror, reflecting the sky and the surrounding snowcapped peaks so pristinely that at times the horizon disappears and the mountains seem like islands floating in the sky.<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 } else if ($thing8) {
	 echo "<b>EXPLORE THE GALAIPAGOS ISLANDS, ECUADOR</b><br>";
     echo "The utter indifference that most of the animals of the Gal�pagos Islands show to humans suggests that they knew all along they�d be the ones to change humanity�s perception of itself for ever. It was, after all, this famous menagerie that started the cogs turning in Charles Darwin�s mind. With each island, new animal oddities reveal themselves � giant tortoises, canoodling waved albatrosses, lumbering land iguanas and Darwin�s finches, to name but a few � each a key player in the world�s most celebrated workshop of evolution.<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 } else if ($thing9) {
	 echo "<b>TOAST BAD WEATHER IN THE SCOTTISH HIGHLANDS</b><br>";
     echo "You can�t visit Scotland without trying the national drink. Whisky has been made here for centuries, with the bare hills, green glens and silvery lochs of the Highlands providing the perfect conditions. Barley grows well thanks to rainy, misty days. Peat � dried and burnt to impart that smoky aroma � forms in the damp bogs. Cool temperatures reduce the �the angels� share� as whiskies mature in barrel. There�s no better place to enjoy a wee dram of a single malt, sit back and take in the view.<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 } else if ($thing10) {
	 echo "<b>BED DOWN IN AN IGLOO, CANADA</b><br>";
     echo "Tucked away between rolling hills and vast stretches of tundra in northern Qu�bec lies a series of igloos. These domed shelters were built by Inuit elders, who carved snowblocks from windswept snowdrifts, using skills passed on from their ancestors. Today, they continue to safeguard hunters as well as welcome adventure seekers. Visitors can feast on caribou stew and frozen Arctic char before falling asleep to the sounds of kids throat-singing and the gentle flicker of the seal-blubber-fuelled qulliq (lamp).<br>";
	 echo "<a href='userpage.php'>Click here to Go Back Your Profile<br></a>";
 }
?>
</body>
</html>
		
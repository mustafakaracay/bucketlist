<html><head><title>Photo Upload</title></head>
<body bgcolor="lightblue"><font size="+1" >

<?php
extract($_REQUEST);
$filename=$_FILES['file']['name'];
$filesize=$_FILES['file']['size'];
$directory='/home/u403979365/public_html/';
$uploadFile = $directory . $filename;
if (move_uploaded_file($_FILES['file']['tmp_name'],$uploadFile)){
	echo "$filename has valid format to upload and uploaded successfully.<br><br> ";
} else {
	echo "$filename upload failed.<br>";
	echo "Please select a valid photo.<br>";
}
?>

<img src="<?php echo $filename;?>" +border="3"><br>
<a href="userpage.php"> Click Here to Go Back Your Profile </a>

</body>
</html>
<html><head><title>10 Things to Do Before You Die</title></head>
<body bgcolor="lightblue"><font size="+1">
	<h1 style="text-align: center"><img src="things.jpg" alt="10 Things to Do Before You Die" /></h1>
	<div>
		<p style="text-align: center"> <b>"Carpe Diem!"</b></p>
		<p style="text-align: center"> <b>[ <a href="signup2.php"> Sign Up </a> ]</b></p>
		<p style="text-align: center"> <b>[ <a href="login2.php"> Login </a> ]</b></p>
	</div>
</body>
</html>
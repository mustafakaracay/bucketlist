<?php
session_start();
?>
<html><head><title>Update Profile</title></head>
<body bgcolor="lightblue"><font size="+1" >
<?php
if (isset($_POST["submit"])) {
$dbservername = "localhost";
$dbusername = "u403979365_root";
$dbpassword = "35248910";
$dbname = "u403979365_user";

$firstnameval = $lastnameval = 1;

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbname);
if (!$conn) {
    die("Connection to mysql failed : " . mysqli_connect_error() . "<br>");
} else {

   if (empty($_POST["firstname"])) {
     $firstnameval = 0;
     echo "First name cannot be empty.<br>";
   } else {
     $firstname = test_input($_POST["firstname"]);
     if (!preg_match("/^[a-zA-Z ]*$/",$firstname)) {
	   $firstnameval = 0;
       echo "Only letters and white space allowed for first name.<br>";
     }
   }
  
   if (empty($_POST["lastname"])) {
     $lastnameval = 0;
     echo "Last name cannot be empty.<br>";
   } else {
     $lastname = test_input($_POST["lastname"]);
     if (!preg_match("/^[a-zA-Z ]*$/",$lastname)) {
	   $lastnameval = 0;
       echo "Only letters and white space allowed for last name.<br>"; 
     }
   }
   
}
	
	$id=$_SESSION["id"];

if (($firstnameval == 1) && ($lastnameval == 1) ) {
	$sql = "UPDATE user SET firstname='$firstname', lastname='$lastname' WHERE id='$id'";
	
	if (mysqli_query($conn, $sql)) {
		echo "Your informations updated successfully<br>";
		echo "You will redirect your profile in 1 seconds";
		header("refresh:1; url=userpage.php");
		exit;
	} else {
		echo "Invalid first name or last name!<br>" ;
		echo "You will redirect edit profile page again in 3 seconds.";
		header("refresh:3; url=updateprofile.php");
		exit;
	}
} else {
	echo "Invalid first name or last name!<br>" ;
	echo "You will redirect edit profile page again in 3 seconds.";
	header("refresh:3; url=updateprofile.php");
	exit;
}

mysqli_close($conn);

} else {
?>

<table>
<tr>
<form method="POST" action="<?php  echo $_SERVER['PHP_SELF'] ?>">
<td>First Name</td>
<td><input type="text" name="firstname"></td>
</tr>
<tr>
<td>Last Name</td>
<td><input type="text" name="lastname"></td>
</tr>
<tr>
<td><input type="submit" name="submit" value="Edit Profile"></td>
</tr>
</form>
</table>
<button onclick="goBack()">Go Back</button>
<script>
function goBack() {
    window.history.back();
}
</script>
<?php
}
?>
</body>
</html>


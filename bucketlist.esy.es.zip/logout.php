<html><head><title>Logout</title></head>
<body bgcolor="lightblue"><font size="+1" >
<?php
session_start();
ob_start();
session_destroy();
echo "Logout succeed.<br>";
echo "You will redirect to mainpage in 1 seconds";
header("Refresh: 1; url=index.php");
ob_end_flush();
?>
</body>
</html>